const router = require("express").Router();

let auth = require("../authtoken");
let jwt = require("jsonwebtoken");

////////////////////////
///////////////////////
const order = require("../controllers/ordercontroller");

//remove order
router.route("/delete/:id").delete((req, res) => {
  Order.Order.findOneAndDelete({ orderid: req.params.id }, (err, result) => {
    if (err) res.json(err);
    else {
      res.json("Order deleted");
    }
  });
});

//add order
router.route("/add").post(auth, order.createOrder);

//accept order
router.route("/searchboy/:chefid/:orderid").get(order.searchboy);

module.exports = router;
