const router = require("express").Router();
const Menu = require("../../models/menu.model");
//--------
const admin = require("../controllers/admincontroller");
const auth = require("../authtoken");
//---------------
router.route("/menu").post(auth, admin.createMenu);
//find all menus
router.route("/findall").get(auth, admin.getAllMenuDetails);

//add products
router.route("/addProduct").put(auth, admin.addItemsToMenu);

//get all chefs

router.route("/chefs/all").get(auth, admin.getAllChefs);
//
router.route("/chefs/active").get(auth, admin.getActiveChefs);
//
router.route("/chefs/delete/:id").delete(auth, admin.deletechef);
//
router.route("/chefs/:id").get(auth, admin.getChefById);

router.route("/serviceboy/all").get(auth, admin.getAllServiceBoys);
//
router.route("/serviceboy/active").get(auth, admin.getActiveBoys);
//
router.route("/serviceboy/:id").get(auth, admin.getBoyById);
//
router.route("/serviceboy/delete/:id").delete(auth, admin.deleteboy);
router.route("/users/all").get(auth, admin.getAllUsers);
router.route("/user/delete/:id").delete(auth, admin.deleteuser);
router.route("/user/:id").get(auth, admin.getUserById);
router.route("/change/price").put(auth, admin.changePrice);
//
router.route("/addcoupon").put(auth, admin.addCoupon);
router.route("/getcoupons").get(auth, admin.getCoupons);
router.route("/updatecoupon").put(auth, admin.updateCoupon);
module.exports = router;
