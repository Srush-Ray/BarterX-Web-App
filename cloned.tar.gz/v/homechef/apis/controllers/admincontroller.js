let User = require("../../models/User.model");
let Homechef = require("../../models/homechef.model");
let Delivery = require("../../models/delivery.model");
let Menu = require("../../models/menu.model");
let jwt = require("jsonwebtoken");
let nodemailer = require("nodemailer");
let transport = require("nodemailer-smtp-transport");
require("dotenv").config();
let bcrypt = require("bcryptjs");
const auth = require("../authtoken");
const Admin = require("../../models/admin.model");
//---------------------------------------------------------//
//----------------------------------------------------------//

module.exports.createMenu = (req, res) => {
  Menu.create(req.body)
    .then((result) => {
      res.send(result);
    })
    .catch((err) => {
      res.send(err).status(400);
    });
};
//-------
//--------
module.exports.getAllMenuDetails = (req, res) => {
  Menu.find()
    .then((menu) => {
      res.json(menu[0].products);
    })
    .catch((err) => res.status(400).json(err));
};
//-----------
//---------
module.exports.addItemsToMenu = (req, res) => {
  Menu.update({}, { $push: { products: req.body } }, { new: true })
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      res.json(err);
    });
};

//-------------
//chefs

module.exports.getAllChefs = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Homechef.find({})
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};
///--------

module.exports.getActiveChefs = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Homechef.find({ isaccepting: "true" })
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

//
module.exports.deletechef = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Homechef.findOneAndDelete({ _id: req.params.id })
          .then((chefs) => {
            res.json({ status: true, data: "Chefs Account Deleted" });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};
//

module.exports.getChefById = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Homechef.findOne({ _id: req.params.id })
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

//boys

module.exports.getAllServiceBoys = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Delivery.find({})
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

//

module.exports.getActiveBoys = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Delivery.find({ isaccepting: "true" })
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

module.exports.deleteboy = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Delivery.findOneAndDelete({ _id: req.params.id })
          .then((chefs) => {
            res.json({ status: true, data: "boys Account Deleted" });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};
//

module.exports.getBoyById = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Delivery.findOne({ _id: req.params.id })
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

//users
module.exports.getAllUsers = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        User.find({})
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

//
module.exports.deleteuser = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        User.findOneAndDelete({ _id: req.params.id })
          .then((chefs) => {
            res.json({ status: true, data: "Users Account Deleted" });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};
//
module.exports.getUserById = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        User.findOne({ _id: req.params.id })
          .then((chefs) => {
            res.json({ status: true, data: chefs });
          })
          .catch((err) => {
            res.json({ status: false, error: err });
          });
      }
    })
    .catch((err) => res.json(err));
};

module.exports.changePrice = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        var id = req.body.itemId;
        var price = req.body.price;

        Menu.updateOne(
          { "products.itemId": id },
          { $set: { "products.$.price": price } }
        ).then((r) => {
          res.json({ status: true, data: "Updated the price" });
        });
        // res.json(arr[0]);
      }
    })
    .catch((err) => res.json(err));
};

//
module.exports.addCoupon = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Admin.findByIdAndUpdate(
          { _id: req.user._id },
          {
            $push: { coupon: req.body },
          }
        )
          .then((resu) => {
            res
              .status(200)
              .json({ status: true, data: "Coupon added to database" });
          })
          .catch((err) => res.json(err));
      }
    })
    .catch((err) => res.json(err));
};

module.exports.getCoupons = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        Admin.findOne({ _id: req.user._id }).then((admin) => {
          res.json({ status: true, data: admin.coupon });
        });
      }
    })
    .catch((err) => res.json(err));
};

module.exports.updateCoupon = (req, res) => {
  Admin.find({ _id: req.user._id })
    .then((user) => {
      if (user.length <= 0)
        res.json({ status: false, error: "Admin access denied" });
      else {
        var code = req.body.couponcode;

        Admin.findOneAndUpdate(
          { "coupon.couponcode": code },
          { $set: { "coupon.$.price": req.body.price } }
        )
          .then((admin) => {
            res.json({ status: true, data: "Min Amount updated " });
          })
          .catch((err) => res.json(err));
      }
    })
    .catch((err) => res.json(err));
};
