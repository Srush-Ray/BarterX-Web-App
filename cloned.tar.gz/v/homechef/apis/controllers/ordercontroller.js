let User = require("../../models/User.model");
let Homechef = require("../../models/homechef.model");
let Delivery = require("../../models/delivery.model");
let Menu = require("../../models/menu.model");
let Admin = require("../../models/admin.model");
let Order = require("../../models/order.model");
let jwt = require("jsonwebtoken");
let nodemailer = require("nodemailer");
let transport = require("nodemailer-smtp-transport");
require("dotenv").config();
let bcrypt = require("bcryptjs");
const auth = require("../authtoken");
//---------------------------------------------------------//
//----------------------------------------------------------//

module.exports.getCoupons = (req, res) => {
  var price = req.body.price;
  var arr = new Array();

  Admin.findOne({})
    .then((admin) => {
      for (var i = 0; i < admin.coupon.length; i++) {
        if (admin.coupon[i].price <= price) {
          arr.push(admin.coupon[i]);
        }
      }
      res.json(arr);
    })
    .catch((err) => res.json(err));
};

module.exports.addCouponToOrder = (req, res) => {
  Admin.findOne({})
    .then((admin) => {
      // console.log(admin.coupon.length);
      for (var i = 0; i < admin.coupon.length; i++) {
        // console.log(admin.coupon[i].couponcode);
        // console.log("===============");
        // console.log(admin.coupon[i].price);
        // console.log("==================");
        // console.log(admin.coupon[i].off);

        if (admin.coupon[i].couponcode == req.body.couponcode) {
          if (admin.coupon[i].price <= req.body.totalCost) {
            var discount =
              totalCost * parseFloat(parseInt(admin.coupon[i].off) / 100);
            console.log(discount);
            res.json({ status: true, data: discount });
          } else {
            res.json({
              status: false,
              error: "Amount is less or invalid coupon",
            });
          }
        }
        console.log(i + " " + " itertation not found");
      }
      // res.json({ status: false, error: "Invalid Coupon " });
    })
    .catch((err) => res.json(err));
};
//mailing options and transportor
var options = {
  service: "gmail",
  auth: {
    user: process.env.EMAILFROM,
    pass: process.env.PASSWORD,
  },
  tls: {
    rejectUnauthorized: false,
  },
};
let client = nodemailer.createTransport(transport(options));
//sms service
const accountSid = process.env.accountSID;
const authToken = process.env.authToken;
const clientSMS = require("twilio")(accountSid, authToken);

//--------------------------
//---------------------------
let data;
let ChefList = new Array();

module.exports.createOrder = (req, res) => {
  data = req.body;
  data.customerid = req.user._id;
  //console.log(data.customerid);
  var longi;
  var lati;
  User.findOne({ _id: data.customerid }).then((user) => {
    lati = user.location.coordinates[0];
    longi = user.location.coordinates[1];
    // console.log(longi + " " + lati);
    //aggregate used///
    console.log("total items:" + data.product.length);
    Homechef.aggregate([
      {
        $geoNear: {
          near: {
            type: "Point",
            coordinates: [parseFloat(lati), parseFloat(longi)],
          },
          distanceField: "dist.calculated",
          maxDistance: 30000000,
          spherical: true,
        },
      },
      // { $match: { isaccepting: true } },
      { $unwind: "$menucooked" },
      {
        $match: {
          "menucooked.subcatogaryName": data.subcatogary,
          "menucooked.catogaryName": data.catogary,
          isaccepting: true,
          excededlimit: false,
          currentorders: { $lt: 3 },
        },
      },
      { $group: { _id: "$_id" } },
      { $sort: { dist: 1 } },
      // {$skip:skips},
    ]).exec((err, result) => {
      if (err) res.json(err);
      else {
        if (result.length > 0) {
          console.log(result);

          Order.Order.create(data)
            .then((order) => {
              User.findByIdAndUpdate(
                { _id: req.user._id },
                { $push: { orders: order._id } }
              )
                .then((user) => {
                  ChefList = result;
                  // console.log(ChefList);

                  let chefId = ChefList[0];
                  Homechef.findOne({ _id: chefId })
                    .then((chef) => {
                      let sendmail = chef.email;
                      console.log(sendmail);

                      let orderdetails = ` Order Id: <b>${order.orderid}</b><br><br>
                      Order Subcatogary <b>: ${order.subcatogary}<b></br><br>
                        Total Cost : <b>${order.totalCost}</b><br><br>
                        Products : <b>(1)</b> ${order.product[0].itemid},Quantity : ${order.product[0].quantity}<br>
                       <h3> <b>To check all products visit site</b></h3>`;

                      var email = {
                        from: process.env.EMAILFROM,
                        to: sendmail,
                        subject: "Cooking Order Notification",
                        text: "Allocated Order Details",
                        html: orderdetails,
                      };
                      client.sendMail(email, (err, info) => {
                        if (err) console.log(err);
                        else {
                          //console.log(info);
                          if (data.product.length >= 3) {
                            Homechef.findOneAndUpdate(
                              { _id: chefId },
                              {
                                $set: {
                                  currentorders: chef.currentorders + 1,
                                  excededlimit: true,
                                },

                                $push: { orders: order._id },
                              }
                            )
                              .then((chef) => {
                                Order.Order.findByIdAndUpdate(
                                  { _id: order._id },
                                  {
                                    $set: {
                                      homechefid: chef._id,
                                      status: "accepted",
                                    },
                                  }
                                )
                                  .then((order) => {
                                    res
                                      .json({
                                        status: true,
                                        data: "Order Placed Succesfully",
                                        redirect: `http://localhost:5000/order/searchboy/${chef._id}/${order._id}`,
                                      })
                                      .status(200);
                                  })
                                  .catch((err) => {
                                    res.json(err);
                                  });
                              })
                              .catch((err) => {
                                res.json(err);
                              });
                          } else {
                            Homechef.findOneAndUpdate(
                              { _id: chefId },
                              {
                                $set: { currentorders: chef.currentorders + 1 },

                                $push: { orders: order._id },
                              }
                            )
                              .then((chef) => {
                                Order.Order.findByIdAndUpdate(
                                  { _id: order._id },
                                  {
                                    $set: {
                                      homechefid: chef._id,
                                      status: "accepted",
                                    },
                                  }
                                )
                                  .then((order) => {
                                    res
                                      .json({
                                        status: true,
                                        data: "Order Placed Succesfully",
                                        redirect: `http://localhost:5000/order/searchboy/${chef._id}/${order._id}`,
                                      })
                                      .status(200);
                                  })
                                  .catch((err) => {
                                    res.json(err);
                                  });
                              })
                              .catch((err) => {
                                res.json(err);
                              });
                          }
                        }
                      });
                    })
                    .catch((err) => {
                      res.json(err);
                    });
                })
                .catch((err) => {
                  res.json(err);
                });
            })
            .catch((err) => {
              res.json(err);
            });
        } else {
          console.log("no heomchef found");
          res
            .json({ status: false, error: "No homechef available" })
            .status(404);
        }
      }
    });
  });
};
//---------------
//-----------------
let serviceboy = new Array();
module.exports.searchboy = (req, res) => {
  Order.Order.findOne({ _id: req.params.orderid })
    .then((order) => {
      if (order.serviceboyid != "null")
        res.json({ status: true, data: "Service boy already alloted " });
      else {
        console.log(order);
        Homechef.findOne({ _id: req.params.chefid })
          .then((chef) => {
            var lat = chef.location.coordinates[0];
            var longi = chef.location.coordinates[1];
            console.log({ lat: lat, longi: longi });
            Delivery.aggregate([
              {
                $geoNear: {
                  near: {
                    type: "Point",
                    coordinates: [parseFloat(lat), parseFloat(longi)],
                  },
                  distanceField: "dist.calculated",
                  maxDistance: 3000000,
                  spherical: true,
                },
              },

              {
                $match: { isaccepting: true },
              },
              // { $group: { _id: "$_id" } },
              { $sort: { dist: 1 } },
              // {$skip:skips},
            ]).exec((err, result) => {
              if (err) res.json(err);
              else {
                if (result.length > 0) {
                  serviceboy = result;
                  console.log(serviceboy);

                  let boyId = serviceboy[0];
                  Delivery.findOne({ _id: boyId })
                    .then((boy) => {
                      let sendmail = boy.email;
                      console.log(boy.email);

                      var email = {
                        from: process.env.EMAILFROM,
                        to: sendmail,
                        subject: "Delivery Order Notification",
                        text: "Incoming order",
                        html: `<h2>Order Id: ${req.params.orderid}</h2>`,
                      };
                      client.sendMail(email, (err, info) => {
                        if (err) console.log(err);
                        else {
                          console.log(info);
                          Order.Order.findOneAndUpdate(
                            { _id: order._id },
                            { serviceboyid: boy._id }
                          )
                            .then((neworder) => {
                              Delivery.findOneAndUpdate(
                                { _id: boy._id },
                                { $push: { orders: neworder._id } }
                              )
                                .then((delboy) => {
                                  res
                                    .json({
                                      status: true,
                                      data: "Service boy alloted ",
                                    })
                                    .status(200);
                                })
                                .catch((err) => {
                                  res.json(err);
                                });
                            })
                            .catch((err) => {
                              res.json(err);
                            });
                        }
                      });
                    })
                    .catch((err) => {
                      res.json(err);
                    });
                } else {
                  console.log("no delivery boy found");

                  res
                    .json({
                      status: false,
                      error: "No delivery boy present",
                    })
                    .status(404);
                }
              }
            });
          })
          .catch((err) => {
            res.json(err);
          });
      }
    })
    .catch((err) => {
      res.json(err);
    });
};
//
//

// // let serviceboy = new Array();
// module.exports.acceptOrder = (req, res) => {
//   Homechef.findOne({ _id: req.params.id }).then((result) => {
//     if (result.tempToken == `rejected${req.params.orderid}`)
//       res
//         .json({ status: false, error: "You have already rejected the order" })
//         .status(408);
//     else {
//       var token = req.params.token;
//       jwt.verify(token, "token", (err, decoded) => {
//         if (err) {
//           // console.log(err);
//           res.json({ status: false, error: err }).status(400);
//         } else {
//           // result.tempToken = "false";
//           // clearTimeout(chefautoreject);
//           Order.Order.findByIdAndUpdate(
//             { _id: req.params.orderid },
//             { homechefid: req.params.id }
//           )
//             .then((order) => {
//               Homechef.findOneAndUpdate(
//                 { _id: req.params.id },
//                 {
//                   $set: { tempToken: `accepted${req.params.orderid}` },
//                   $push: { orders: order._id },
//                 }
//               )
//                 .then((chef) => {
//                   Order.Order.findByIdAndUpdate(
//                     { _id: order._id },
//                     { status: "accepted" }
//                   )
//                     .then((neworder) => {
//                       var lati = chef.location.coordinates[0];
//                       var longi = chef.location.coordinates[1];
//                       // console.log(longi + " " + lati);
//                       //aggregate used///
//                       Delivery.aggregate([
//                         {
//                           $geoNear: {
//                             near: {
//                               type: "Point",
//                               coordinates: [
//                                 parseFloat(lati),
//                                 parseFloat(longi),
//                               ],
//                             },
//                             distanceField: "dist.calculated",
//                             maxDistance: 3000000,
//                             spherical: true,
//                           },
//                         },

//                         {
//                           $match: { isaccepting: true },
//                         },
//                         // { $group: { _id: "$_id" } },
//                         { $sort: { dist: 1 } },
//                         // {$skip:skips},
//                       ]).exec((err, result) => {
//                         if (err) res.json(err);
//                         else {
//                           if (result.length > 0) {
//                             serviceboy = result;
//                             //console.log(serviceboy);

//                             let boyId = serviceboy[0];
//                             Delivery.findOne({ _id: boyId })
//                               .then((boy) => {
//                                 // console.log(boy);
//                                 boy.tempToken = jwt.sign(
//                                   { _id: boyId, email: boy.email },
//                                   "token",
//                                   {
//                                     expiresIn: "10m",
//                                   }
//                                 );
//                                 let sendmail = boy.email;
//                                 console.log(boy.email);
//                                 let AcceptLink =
//                                   "http://localhost:5000/order/acceptdelivery/" +
//                                   boy._id +
//                                   "/" +
//                                   boy.tempToken +
//                                   "/" +
//                                   neworder._id;
//                                 let RejectLink =
//                                   "http://localhost:5000/order/rejectdelivery/" +
//                                   boy._id +
//                                   "/" +
//                                   neworder._id;
//                                 console.log(neworder._id);
//                                 var email = {
//                                   from: process.env.EMAILFROM,
//                                   to: sendmail,
//                                   subject: "Delivery Order Notification",
//                                   text: "Accept or reject the incoming order",
//                                   html:
//                                     "Order details    catogary    " +
//                                     neworder.catogary +
//                                     "<br>" +
//                                     '<h5>Link to accept order <a href="' +
//                                     AcceptLink +
//                                     '"> Accept </a></h5><br><h5>Link to reject order  <a href="' +
//                                     RejectLink +
//                                     '"> Reject </a></h5><br>',
//                                 };
//                                 client.sendMail(email, (err, info) => {
//                                   if (err) console.log(err);
//                                   else {
//                                     console.log(info);
//                                   }
//                                 });
//                               })
//                               .catch((err) => {
//                                 res.json(err);
//                               });
//                             res
//                               .json({ status: true, data: "Order Accepted " })
//                               .status(200);
//                           } else {
//                             console.log("no delivery boy found");

//                             res
//                               .json({
//                                 status: false,
//                                 error: "No delivery boy present",
//                               })
//                               .status(404);
//                           }
//                         } //)
//                       });
//                     })
//                     .catch((err) => {
//                       res.json(err);
//                     }); //after delivery
//                 })
//                 .catch((err) => {
//                   res.json(err);
//                 });
//             })
//             .catch((err) => {
//               res.json(err);
//             });
//         }
//       });
//     }
//   });
// };
// //---------------
// //---------------
// module.exports.rejectOrder = (req, res) => {
//   Order.Order.findOne({ _id: req.params.orderid }).then((order) => {
//     if (order.homechefid == req.params.id)
//       res
//         .json({ status: false, error: "You have accepted the order" })
//         .status(400);
//     else {
//       Homechef.findOneAndUpdate(
//         { _id: req.params.id },
//         { tempToken: `rejected${req.params.orderid}` }
//       )
//         .then((result) => {
//           {
//             ChefList.shift();
//             if (ChefList.length > 0) {
//               let chefId = ChefList[0];
//               console.log(chefId);
//               Homechef.findOne({ _id: chefId })
//                 .then((chef) => {
//                   chef.tempToken = jwt.sign(
//                     { _id: chefId, email: chef.email },
//                     "token",
//                     {
//                       expiresIn: "10m",
//                     }
//                   );

//                   let sendmail = chef.email;
//                   let AcceptLink =
//                     "http://localhost:5000/order/accept/" +
//                     chef._id +
//                     "/" +
//                     chef.tempToken +
//                     "/" +
//                     req.params.orderid;
//                   console.log(req.params.orderid);
//                   let RejectLink =
//                     "http://localhost:5000/order/reject/" +
//                     chef._id +
//                     "/" +
//                     req.params.orderid;
//                   var email = {
//                     from: process.env.EMAILFROM,
//                     to: sendmail,
//                     subject: "Cooking Order Notification",
//                     text: "Accept or reject the incoming order",
//                     html:
//                       " <h2>We will inform when to start cooking</h2> " +
//                       // "<h1></h1>Link valid for 1 hour.Click to verify our email. <a href='http://localhost:5000/users/verifiedCustomer/${result.tempToken}'> here</a>",
//                       '<h5>Link to accept order <a href="' +
//                       AcceptLink +
//                       '"> Accept </a></h5><br><h5>Link to reject order  <a href="' +
//                       RejectLink +
//                       '"> Reject </a></h5><br>',
//                   };
//                   client.sendMail(email, (err, info) => {
//                     if (err) res.json(err);
//                     else {
//                       res.status(200);
//                       chefautoreject = setTimeout(() => {
//                         //console.log("intimeout");
//                         res.redirect(
//                           `http://localhost:5000/order/reject/${chef._id}/${req.params.id}`
//                         );
//                       }, 60000);
//                     }
//                   });
//                 })
//                 .catch((err) => {
//                   res.json(err);
//                 });
//             } else {
//               console.log("no heomchef found");
//               Order.Order.findByIdAndDelete({ _id: order._id })
//                 .then((result) => {
//                   res
//                     .json({ status: false, error: "No homechef available" })
//                     .status(404);
//                 })
//                 .catch((err) => {
//                   res.json({ status: false, error: err }).status(404);
//                 });
//             }
//           }
//         })
//         .catch((err) => {
//           res.json(err);
//         });
//     }
//   });
// };

// module.exports.deliveryacceptorder = (req, res) => {
//   console.log(req.params.id);
//   console.log("============");
//   Delivery.findOne({ _id: req.params.id }).then((result) => {
//     if (result.tempToken == `rejected${req.params.orderid}`)
//       res
//         .json({ status: false, error: "You have already rejected the order" })
//         .status(408);
//     else {
//       var token = req.params.token;
//       jwt.verify(token, "token", (err, decoded) => {
//         if (err) {
//           // console.log(err);
//           res.json({ status: false, error: err }).status(400);
//         } else {
//           // result.tempToken = "false";
//           Order.Order.findByIdAndUpdate(
//             { _id: req.params.orderid },
//             { serviceboyid: req.params.id }
//           )
//             .then((order) => {
//               Delivery.findOneAndUpdate(
//                 { _id: req.params.id },
//                 {
//                   $set: { tempToken: `accepted${req.params.orderid}` },
//                   $push: { orders: order._id },
//                 }
//               )
//                 .then((boy) => {
//                   Homechef.findOne({ _id: order.homechefid })
//                     .then((chef) => {
//                       var sendmail = chef.email;
//                       var email = {
//                         from: process.env.EMAILFROM,
//                         to: sendmail,
//                         subject: "Start Cooking Order Notification",
//                         text: "",
//                         html: "<h2>You can start cooking now</h2>",
//                       };
//                       client.sendMail(email, (err, info) => {
//                         if (err) console.log(err);
//                         else {
//                           console.log(info);
//                         }
//                       });
//                       res.json({ status: true, data: "Delivery boy assigned" });
//                     })
//                     .catch((err) => {
//                       err;
//                     });
//                 })
//                 .catch((err) => {
//                   res.json(err);
//                 });
//             })
//             .catch((err) => {
//               res.json(err);
//             });
//         }
//       });
//     }
//   });
// };

// //---------------
// //---------------
// module.exports.deliveryrejectOrder = (req, res) => {
//   console.log(req.params.id);
//   // Homechef.findOne({_id:req.params.id}).then(rejectchef=>{
//   //   if(rejectchef.tempToken=="accepted")res.json({status:false,error:"You have accepted the order"}).status(400)
//   // })
//   Order.Order.findOne({ _id: req.params.orderid }).then((order) => {
//     if (order.serviceboyid == req.params.id)
//       res
//         .json({ status: false, error: "You have accepted the order" })
//         .status(400);
//     else {
//       Delivery.findOneAndUpdate(
//         { _id: req.params.id },
//         { tempToken: `rejected${req.params.orderid}` }
//       )
//         .then((result) => {
//           {
//             serviceboy.shift();
//             if (serviceboy.length > 0) {
//               let boyId = serviceboy[0];
//               console.log(boyId);
//               Delivery.findOne({ _id: boyId })
//                 .then((boy) => {
//                   boy.tempToken = jwt.sign(
//                     { _id: boyId, email: boy.email },
//                     "token",
//                     {
//                       expiresIn: "10m",
//                     }
//                   );

//                   let sendmail = boy.email;
//                   let AcceptLink =
//                     "http://localhost:5000/order/acceptdelivery/" +
//                     boy._id +
//                     "/" +
//                     boy.tempToken +
//                     "/" +
//                     req.params.orderid;
//                   console.log(req.params.orderid);
//                   let RejectLink =
//                     "http://localhost:5000/order/rejectdelivery/" +
//                     boy._id +
//                     "/" +
//                     req.params.orderid;
//                   var email = {
//                     from: process.env.EMAILFROM,
//                     to: sendmail,
//                     subject: "Delivery Order Notification",
//                     text: "Accept or reject the incoming order",
//                     html:
//                       // "<h1></h1>Link valid for 1 hour.Click to verify our email. <a href='http://localhost:5000/users/verifiedCustomer/${result.tempToken}'> here</a>",
//                       '<h5>Link to accept order <a href="' +
//                       AcceptLink +
//                       '"> Accept </a></h5><br><h5>Link to reject order  <a href="' +
//                       RejectLink +
//                       '"> Reject </a></h5><br>',
//                   };
//                   client.sendMail(email, (err, info) => {
//                     if (err) res.json(err);
//                     else {
//                       res.json(info);
//                       // setTimeout(() => {
//                       //   console.log("intimeout");
//                       //   res.redirect(`http://localhost:5000/order/reject/${chef._id}`);
//                       // }, 300000);
//                     }
//                   });
//                 })
//                 .catch((err) => {
//                   res.json(err);
//                 });
//             } else {
//               console.log("no delivery");
//               Homechef.findOne({ _id: order.homechefid })
//                 .then((chef) => {
//                   var sendmail = chef.email;
//                   let statusLink =
//                     "http://localhost:5000/homechef/orderstatus/rejected" +
//                     "/" +
//                     order.orderid;
//                   var email = {
//                     from: process.env.EMAILFROM,
//                     to: sendmail,
//                     subject: "NO delivery boy available Notification",
//                     text: "",
//                     html:
//                       "<h2>Mark the order Status as rejected</h2>" +
//                       "<h3><a href=" +
//                       statusLink +
//                       '"> Reject </a></h3><br>',
//                   };
//                   client.sendMail(email, (err, info) => {
//                     if (err) console.log(err);
//                     else {
//                       console.log(info);
//                     }
//                   });
//                   res.json({ status: true, data: "Delivery boy assigned" });
//                 })
//                 .catch((err) => {
//                   err;
//                 });

//               res.json("no delivery").status(404);
//             }
//           }
//         })
//         .catch((err) => {
//           res.json(err);
//         });
//     }
//   });
// };
