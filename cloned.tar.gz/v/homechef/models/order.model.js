const mongoose = require("mongoose");
const schema = mongoose.Schema;

const orderschema = new schema(
  {
    //orderid: { type: String, required: true },
    customerid: { type: String, default: "null" },
    homechefid: { type: String, default: "null" },
    serviceboyid: { type: String, default: "null" },
    chefcoords: { type: [Number] },
    customercoords: { type: [Number] },
    status: {
      type: String,
      default: "waiting",
      enum: [
        "accepted",
        "waiting",
        "preparing",
        "dispatched",
        "deliverd",
        "rejected",
      ],
    },
    subcatogary: { type: String, required: true },
    catogary: { type: String, required: true },
    product: [
      {
        itemid: { type: String },
        quantity: { type: Number },
        totalprice: { type: Number },
        detailsifany: { type: String },
      },
    ],
    paymentType: { type: String },
    totalCost: { type: Number },
    paymentdone: { type: Boolean, default: "false", required: true },
    couponcode: { type: String },
    discountprice: { type: Number },
  },

  { timestamps: true }
);

const Order = mongoose.model("Order", orderschema);

module.exports.Order = Order;
