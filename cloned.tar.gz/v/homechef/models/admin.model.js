const mongoose = require("mongoose");
const schema = mongoose.Schema;

const adminschema = new schema(
  {
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    name: { type: String, required: true },
    isVerified: { type: Boolean, default: "false" },
    tempToken: { type: String, required: true, default: "null" },

    address: {
      type: String,
      required: true,
    },

    phone: { type: Number, required: true },
    email: { type: String, required: true },
    coupon: { type: Array, default: [] },
  },

  { timestamps: true }
);
// homechefschema.index({ location: "2dsphere" });

const Admin = mongoose.model("Admin", adminschema);

module.exports = Admin;
